package com.igate.donorapplication.dto;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Author 		: @author sn825940 
 * Class Name 	: DonorDTO 
 * Package 		: com.igate.donorapplication.dto 
 * Date 		: Sep 12, 2014
 */

public class DonorDTO {
	private int donorId;
	private String donorName;
	private long phoneNumber;
	private String address;
	private double amount;
	private Calendar donationDate;

	/**
	 * Constructors
	 */

	public DonorDTO() {

	}

	public DonorDTO(int donorId, String donorName, long phoneNumber,
			String address, double amount) {
		super();
		this.donorId = donorId;
		this.donorName = donorName;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.amount = amount;
	}

	/**
	 * Getter and Setter Methods
	 */

	public int getDonorId() {
		return donorId;
	}

	public void setDonorId(int donorId) {
		this.donorId = donorId;
	}

	public String getDonorName() {
		return donorName;
	}

	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getDonationDate() {
		/* Calendar Date Converted to String format for Displaying to User */
		java.util.Date date = donationDate.getTime();
		SimpleDateFormat frmat = new SimpleDateFormat("dd-MMM-yyyy");
		String jDate = frmat.format(date);
		return jDate;
	}

	public void setDonationDate(Calendar donationDate) {
		this.donationDate = donationDate;
	}

	/**
	 * toString() Method
	 */
	public String toString() {

		return "<tr><td>" + donorId + "</td><td>" + donorName + "</td><td>"
				+ phoneNumber + "</td><td>" + address + "</td><td>" + amount
				+ "</td><td>" + donationDate + "</td></tr>";
	}
}
