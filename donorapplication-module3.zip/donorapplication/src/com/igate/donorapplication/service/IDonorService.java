package com.igate.donorapplication.service;

import java.util.List;

import com.igate.donorapplication.dto.DonorDTO;
import com.igate.donorapplication.exception.DonorTransactionException;

public interface IDonorService {
	public int addDonor(DonorDTO donor) throws DonorTransactionException;

	public DonorDTO getDonor(int donorId) throws DonorTransactionException;

	public List<DonorDTO> getAllDonor()throws DonorTransactionException;
}
