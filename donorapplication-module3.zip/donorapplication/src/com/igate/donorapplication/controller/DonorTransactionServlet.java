

/**
 * Author		:	@author sn825940
 * Class Name	:	DonorTransactionServlet
 * Package		:	com.igate.donorapplication.controller;
 * Date			:	Sep 12, 2014
 */

package com.igate.donorapplication.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.donorapplication.dto.DonorDTO;
import com.igate.donorapplication.exception.DonorTransactionException;
import com.igate.donorapplication.service.DonorImplService;
import com.igate.donorapplication.service.IDonorService;


/**
 * Servlet implementation class DonorTransactionServlet
 */
public class DonorTransactionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DonorTransactionServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String targetHome = "view/index.jsp";
		if ("back".equals(request.getParameter("input"))) {
			session.setAttribute("error", null);
			session.setAttribute("donor", null);
			RequestDispatcher requestDispatcher = request
					.getRequestDispatcher(targetHome);
			requestDispatcher.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		// Object creations
		DonorDTO donor = new DonorDTO();
		
		IDonorService donorServ = new DonorImplService();
		DonorImplService donorService=new DonorImplService();
		String targetAdd = "view/AddDonor.jsp";
		String targetSuccess = "view/Success.jsp";
		String targetView = "view/ViewDonation.jsp";
		String targetViewAll = "view/ViewAllDonations.jsp";
		String targetError = "view/Error.jsp";
		try {
			/**
			 * Code for Donating
			 */
			String input=request.getParameter("input");
			if ("Donate Now".equals(input)) {
				List<String> errorList = new ArrayList<String>();
				String donorName = request.getParameter("donorName").trim();
				long phoneNumber = Long.parseLong(request.getParameter(
						"phoneNumber").trim());
				String address = request.getParameter("address").trim();
				double amount = Double.parseDouble(request.getParameter(
						"amount").trim());

				donor.setDonorName(donorName);
				donor.setAddress(address);
				donor.setPhoneNumber(phoneNumber);
				donor.setAmount(amount);
				Calendar c1 = Calendar.getInstance();
				donor.setDonationDate(c1);
				errorList = donorService.isValidated(donor);
				if (errorList.isEmpty()) {
					// Code for Adding donation Details
					int donorId = donorServ.addDonor(donor);
					if (donorId != 0) {
						donor.setDonorId(donorId);

						// set ID to display ID alone
						// session.setAttribute("donorId", donorId);
						session.setAttribute("donor", donor);
						RequestDispatcher requestDispatcher = request
								.getRequestDispatcher(targetSuccess);
						requestDispatcher.forward(request, response);
					}

				} else {
					session.setAttribute("errorList", errorList);
					RequestDispatcher requestDispatcher = request
							.getRequestDispatcher(targetAdd);
					requestDispatcher.forward(request, response);
				}
			}

			/**
			 * Redirect to Add donor Page
			 */
			
			else if ("Add Donor".equals(input)) {
				RequestDispatcher requestDispatcher = request
						.getRequestDispatcher(targetAdd);
				requestDispatcher.forward(request, response);

			}

			/**
			 * Redirect to View Donation Page
			 */
			else if ("View Donor".equals(input)) {
				session.setAttribute("error", null);
				RequestDispatcher requestDispatcher = request
						.getRequestDispatcher(targetView);
				requestDispatcher.forward(request, response);

			}

			/**
			 * Redirect to View All Donation Page
			 */
			else if ("View All Donors".equals(input)) {
				List<DonorDTO> donorList = donorServ.getAllDonor();
				if (!donorList.isEmpty()) {
					session.setAttribute("error", null);
					session.setAttribute("donorList", donorList);
					RequestDispatcher requestDispatcher = request
							.getRequestDispatcher(targetViewAll);
					requestDispatcher.forward(request, response);
				} else {
					session.setAttribute("donorList", null);
					session.setAttribute("error", "Sorry No data Found!");
					RequestDispatcher requestDispatcher = request
							.getRequestDispatcher(targetViewAll); 
					requestDispatcher.forward(request, response);
				}
			}

			/**
			 * Code for Searching a particular donor history
			 */
			else if ("Search".equals(input)) {
				int donorId = Integer.parseInt(request.getParameter("donorId"));
				donor = donorServ.getDonor(donorId);
				if (donor.getDonorId() != 0) {
					session.setAttribute("error", null);
					session.setAttribute("donor", donor);
					RequestDispatcher requestDispatcher = request
							.getRequestDispatcher(targetView);
					requestDispatcher.forward(request, response);
				} else {
					session.setAttribute("donor", null);
					session.setAttribute("error",
							"Sorry No data Found for given ID!");
					RequestDispatcher requestDispatcher = request
							.getRequestDispatcher(targetView);
					requestDispatcher.forward(request, response);
				}
			}
		} 
		 catch (DonorTransactionException e) {
			session.setAttribute("error", e.getMessage());
			RequestDispatcher requestDispatcher = request
					.getRequestDispatcher(targetError);
			requestDispatcher.forward(request, response);
		} catch (Exception e) {
			session.setAttribute("error", "Error Occured:" + e.getMessage());
			RequestDispatcher requestDispatcher = request
					.getRequestDispatcher(targetError);
			requestDispatcher.forward(request, response);
		}

	}

}
