package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Bill;
import com.cg.exception.BillException;
import com.cg.service.EBillServiceImpl;
import com.cg.service.IEBillService;

@WebServlet("*.do")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EBillController() {

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath();
		System.out.println(path);

		Bill bill = new Bill();

		IEBillService service = new EBillServiceImpl();
		if (path.equals("/authenticate.do")) {
			String uname = request.getParameter("uname");
			String password = request.getParameter("password");

			if ((uname.equals("mrun")) && (password.equals("123456"))) {
				// response.sendRedirect("Success.html");

				// start a session
				HttpSession session = request.getSession(true); // create a
				// session
				// //assume
				// session is
				// not created
				// so set true
				// so that
				// session is
				// created
				System.out.println(session.getId());
				session.setAttribute("data", bill);
				RequestDispatcher rd = request
						.getRequestDispatcher("mainMenu.jsp");
				rd.forward(request, response);

			}

		}

		else if (path.equals("/calculate.do")) {

			String con_no = request.getParameter("cno");

			Pattern patt = Pattern.compile("^[1-9]{6}//d");
			Matcher mat = patt.matcher(con_no);
			if (!mat.matches()) {
				String err = "Should contain 6 digits";
				request.setAttribute("error", err);
				RequestDispatcher rd = request
						.getRequestDispatcher("mainMenu.jsp");
				rd.forward(request, response);

				try {
					throw new BillException("Should contain 6 digits");
				} catch (BillException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				int last_read = Integer.parseInt(request.getParameter("last"));
				int curr_read = Integer.parseInt(request
						.getParameter("current"));
				// Bill bill = new Bill();

				int c_no = Integer.parseInt(con_no);

				bill.setC_no(c_no);
				bill.setLast_read(last_read);
				bill.setCurr_read(curr_read);

				bill = service.calBill(bill);
				System.out.println(bill.getUnit_con());

				request.setAttribute("dataname", bill.getC_name());
				request.setAttribute("data", bill.getC_no());
				request.setAttribute("data1", bill.getUnit_con());
				request.setAttribute("data2", bill.getNet_Amt());
				RequestDispatcher rd = request
						.getRequestDispatcher("result.jsp");
				rd.forward(request, response);
				int i = service.addUsers(bill);
				System.out.println("inserted---------->" + i);
				//request.setAttribute("data", myList);
				RequestDispatcher rd1 = request.getRequestDispatcher("index.jsp");
				rd1.forward(request, response);
			}
		}

		else if(path.equals("/list.do")){
			List<Bill> myList = new ArrayList<Bill>();
			try {
				myList = service.showAll();
			} catch (BillException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("data", myList);
			RequestDispatcher rd = request.getRequestDispatcher("showAll.jsp");
			rd.forward(request, response);
		}
	}

}
