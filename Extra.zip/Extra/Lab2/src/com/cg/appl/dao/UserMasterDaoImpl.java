package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;
import com.cg.appl.util.JdbcUtil;

public class UserMasterDaoImpl implements UserMasterDao {
	private JdbcUtil util;
	Connection connect=null;
	PreparedStatement stat=null;
	ResultSet rs=null;
	public  UserMasterDaoImpl(){
		util = new JdbcUtil();
	}
	@Override
	public User getUserDetails(String userName) throws UserException {
		
		String qry= "SELECT PASSWORD, USERFNAME FROM USERMASTER WHERE USERNAME=?";
		try {
			connect = util.getConnection();
			stat = connect.prepareStatement(qry);
			stat.setString(1, userName);
			
		    rs=stat.executeQuery();
			
			if(rs.next()){
				
				String password= rs.getString("PASSWORD");
				String fullname = rs.getString("USERFNAME");
				User user = new User(userName, password, fullname);
				return user;
			}else{
				throw new UserException("Username wrong");
			}
			
		} catch (SQLException e) {
			throw new UserException("JDBC failed",e);
		
		}finally{
		
				
					try {
						if(rs!=null){
						rs.close();
					}
					if(stat!=null){
						stat.close();
						
					}
					if(connect!=null){
						connect.close();
					}
					
					} catch (SQLException e) {
						throw new UserException("JDBC closing connection failed");
						
					}
				
				}
		
	}

}
