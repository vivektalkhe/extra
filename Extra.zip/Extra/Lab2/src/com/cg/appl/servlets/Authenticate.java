package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





import com.cg.appl.exceptions.UserException;
import com.cg.appl.services.UserMasterServices;
import com.cg.appl.services.UserMasterServicesImpl;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserMasterServices services;
	public void init(ServletConfig config) throws ServletException {
		services = new UserMasterServicesImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		/*String userName = request.getParameter("userNm");
		String password = request.getParameter("password");
		
		System.out.println(userName +"    "+password);*/
		
	}

	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String userName = req.getParameter("userNm");
		String password = req.getParameter("password");
		RequestDispatcher dispatch = null;
		String nextJsp = null;
		String message = null;
		try{
			boolean isAunthenticated = services.isUserAuthenticated(userName, password);
			if(isAunthenticated){
			//System.out.println("yes");
				/*dispatch = req.getRequestDispatcher("/mainMenu.jsp");
				dispatch.forward(req, resp);*/
				//nextJsp = "/mainMenu.jsp";
				resp.sendRedirect("/mainMenu.jsp");
		}else{
			//System.out.println("no");
			message = "Wrong Credentials.  Enter again:";
			req.setAttribute("errorMsg",message);
			//nextJsp = "/login.jsp";
			resp.sendRedirect("/login.jsp");
		}}
	
		 catch (UserException e) {
		
			//e.printStackTrace();
			 message = "User name does not exist";
			 req.setAttribute("errorMsg",message);
			 
			// nextJsp = "/error.jsp";
			 resp.sendRedirect("/error.jsp");
			 
		}
		/*dispatch = req.getRequestDispatcher(nextJsp);
		dispatch.forward(req, resp);*/
		//System.out.println(userName +"    "+password);
}
		

	public void destroy() {
		
	}

	
}
