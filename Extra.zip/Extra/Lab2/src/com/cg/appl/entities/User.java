package com.cg.appl.entities;

import java.io.Serializable;

public class User implements Serializable {

	
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private String userName;
		private String password;
		private String userFullName;
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getUserFullName() {
			return userFullName;
		}
		public void setUserFullName(String userFullName) {
			this.userFullName = userFullName;
		}
		public User(String userName, String password, String userFullName) {
			super();
			this.userName = userName;
			this.password = password;
			this.userFullName = userFullName;
		}
		


	}


