package com.cg.appl.services;

import com.cg.appl.entities.User;
import com.cg.appl.exceptions.UserException;

public interface UserMasterServices {
	
	public User getUserDetails(String userName) throws UserException;
	boolean isUserAuthenticated(String userName,String password) throws UserException;
}
