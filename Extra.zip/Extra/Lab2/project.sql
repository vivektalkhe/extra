select * from EMP;
drop table user;
create table usermaster(
USERNAME VARCHAR2(15) PRIMARY KEY,
PASSWORD VARCHAR2(15),

USERFNAME VARCHAR2(40));

insert into usermaster (USERNAME, PASSWORD , USERFNAME) values ('a','a','Chandra');
insert into usermaster (USERNAME, PASSWORD , USERFNAME) values ('b','b','Namo');
SELECT * FROM USERMASTER;