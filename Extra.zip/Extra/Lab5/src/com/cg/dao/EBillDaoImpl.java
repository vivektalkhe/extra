package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import com.cg.dto.Bill;
import com.cg.util.DbUtil;

public class EBillDaoImpl implements IEBillDao {

	@Override
	public Bill calBill(Bill bill) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs=null;
		String name=null;
			int unit_con,netAmt;
			
			con = DbUtil.obtainConnection();
			String query = "Select consumer_name from Consumers where consumer_num=?";
			try {
				ps=con.prepareStatement(query);
				ps.setInt(1, bill.getC_no());
				rs=ps.executeQuery();
				
				while(rs.next()){
				name = rs.getString("consumer_name");
			}} catch (SQLException e) {

				e.printStackTrace();
			}
			
			
			
			unit_con= bill.getLast_read()-bill.getCurr_read();
			System.out.println(unit_con);
			netAmt =(int) (unit_con *1.15+100);
			System.out.println(netAmt);
			bill.setUnit_con(unit_con);
			bill.setNet_Amt(netAmt);
			bill.setC_name(name);
			
			return bill;
		}
	
	
	
	public int addUsers(Bill bill) {
		Connection con = null;
		PreparedStatement ps = null;
		//ResultSet rs = null;
		int status=0;
		System.out.println("start");
		int bill_no=getPurchaseId();
		System.out.println("---------->"+bill_no);
		try {
			
			con = DbUtil.obtainConnection();
			String query = "INSERT INTO BillDetails VALUES(?,?,?,?,?,?)";
				ps = con.prepareStatement(query);
				
				System.out.println(bill_no);
				ps.setInt(1, bill_no);
				ps.setInt(2, bill.getC_no());
				ps.setInt(3, bill.getCurr_read());
				ps.setInt(4, bill.getUnit_con());
				ps.setInt(5, bill.getNet_Amt());
				
				Calendar calendar = Calendar.getInstance();
			    java.sql.Date currentDate = new java.sql.Date(calendar.getTime().getTime());
		    	 ps.setDate(6, currentDate);
		

			 status = ps.executeUpdate();
				if(status==1){
					System.out.println("--INSERTED--");
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				// System.out.println(e.getMessage());
				//throw new UsersException("Problem in closing Connection ");
			}

		}

		return status;

	}
	
	public int getPurchaseId() {
		int id=0;
		String query="SELECT seq_bill_num.NEXTVAL FROM DUAL";
		Connection con = null;
		PreparedStatement ps=null;
		ResultSet rs = null;
		try {
			con = DbUtil.obtainConnection();
			ps=con.prepareStatement(query);
			rs=ps.executeQuery();
			while(rs.next()){
			id=rs.getInt(1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return id;

	
	}
	}

