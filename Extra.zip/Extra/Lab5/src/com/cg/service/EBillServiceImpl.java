package com.cg.service;

import com.cg.dao.EBillDaoImpl;
import com.cg.dao.IEBillDao;
import com.cg.dto.Bill;

public class EBillServiceImpl implements IEBillService {

	IEBillDao dao= new EBillDaoImpl();
	
	@Override
	public Bill calBill(Bill bill) {
		
		return dao.calBill(bill);
	}

	@Override
	public int addUsers(Bill bill) {
		
		return dao.addUsers(bill);
	}

}
