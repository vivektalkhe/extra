package com.cg.employeemanagement.service;

import java.util.List;

import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.IEmployeeDao;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDao empDao;

	public EmployeeServiceImpl() {
		empDao = new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {

		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {

		return empDao.showAll();
	}

	@Override
	public Employee getEmployeeDetails(int id) {
		
		return empDao.getEmployeeDetails(id);
	}

	@Override
	public boolean updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.updateEmployee(emp);
	}

	@Override
	public boolean deleteEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return empDao.deleteEmployee(emp);
	}

}
