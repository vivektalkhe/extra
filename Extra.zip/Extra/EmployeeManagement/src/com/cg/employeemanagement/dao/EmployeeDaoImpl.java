package com.cg.employeemanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.exception.EmployeeException;
import com.cg.employeemanagement.util.DbUtil;

public class EmployeeDaoImpl implements IEmployeeDao {

	Connection con = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	int empId = getEmployee();

	int msg=0;
	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		try {
			con = DbUtil.obtainConnection();
			String query = "INSERT INTO employeemanagement VALUES(?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setInt(1, empId);
			ps.setString(2, emp.getEmpname());
			ps.setString(3, emp.getEmpQualification());
			ps.setDouble(4, emp.getEmpSal());
			
			int status = ps.executeUpdate();
			
			if(status==1){
				msg=empId;
			}

		} catch (EmployeeException | SQLException e) {
			throw new EmployeeException("Not Inserted");
		}
		finally{
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				//System.out.println(e.getMessage());
				throw new EmployeeException("Problem in closing Connection ");
			}
			
		}

		return msg;
	}

	@Override
	public List<Employee> showAll() throws EmployeeException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Employee>myEmp = new ArrayList<>();
		String query="select emp_id,emp_name,emp_qual,emp_sal from employeemanagement order by emp_id";
		try {
			con=DbUtil.obtainConnection();
			ps=con.prepareStatement(query);
			rs= ps.executeQuery();
			while(rs.next()){
				Employee emp = new Employee();
				
				emp.setEmpId(rs.getInt("emp_id"));
				emp.setEmpname(rs.getString("emp_name"));
				emp.setEmpQualification(rs.getString("emp_qual"));
				emp.setEmpSal(rs.getDouble("emp_sal"));
				myEmp.add(emp);
			}
		} catch (EmployeeException | SQLException e) {
			throw new EmployeeException("Problem in show");
		}finally{
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		return myEmp;
	}

	
	public int getEmployee(){
		int empId=0;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String query="select empm_id_seq.nextval from dual";
		try {
			con=DbUtil.obtainConnection();
			ps=con.prepareStatement(query);
			rs = ps.executeQuery();
			while(rs.next()){
				empId=rs.getInt(1);
			}
			
		} catch (EmployeeException | SQLException e) {
			try {
				throw new EmployeeException("error");
			} catch (EmployeeException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return empId;
	}

	@Override
	public Employee getEmployeeDetails(int id) {
		String query="select emp_id,emp_name,emp_qual,emp_sal from employeemanagement where emp_id=?";
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Employee emp = new Employee();
		try {
			con=DbUtil.obtainConnection();
			ps=con.prepareStatement(query);
			ps.setInt(1,id);
			rs=ps.executeQuery();
			while(rs.next()){
				
				emp.setEmpId(rs.getInt("emp_id"));
				emp.setEmpname(rs.getString("emp_name"));
				emp.setEmpQualification(rs.getString("emp_qual"));
				emp.setEmpSal(rs.getDouble("emp_sal"));
				
			}
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return emp;
	}

	@Override
	public boolean updateEmployee(Employee emp) throws EmployeeException {

		String query="update employeemanagement set emp_name=?,emp_qual=?,emp_sal=? where emp_id=?";
		Connection con = null;
		PreparedStatement ps = null;
		//ResultSet rs = null;
		int rec=0;
		//List<Employee> myList = new ArrayList<>();
		
		try {
			con=DbUtil.obtainConnection();
			ps=con.prepareStatement(query);
			ps.setString(1,emp.getEmpname());
			
			ps.setString(2, emp.getEmpQualification());
			System.out.println(emp.getEmpQualification());
			ps.setDouble(3, emp.getEmpSal());
			ps.setInt(4, emp.getEmpId());
			
			 rec=ps.executeUpdate();
			if(rec>0){
				
				return true;
			}
			else{
				System.out.println("unSuccessfully Updated");
			}
			
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Not updated");
		}
		
		
		return false;
	}

	@Override
	public boolean deleteEmployee(Employee emp) throws EmployeeException {
		String query="delete from employeemanagement where emp_id=?";
		Connection con = null;
		PreparedStatement ps = null;
		//ResultSet rs = null;
		int rec=0;
		//List<Employee> myList = new ArrayList<>();
		
		try {
			con=DbUtil.obtainConnection();
			ps=con.prepareStatement(query);
			ps.setInt(1,emp.getEmpId());
			 rec=ps.executeUpdate();
			if(rec>0){
				
				return true;
			}
			else{
				System.out.println("unSuccessfully deleted");
			}
			
		} catch (EmployeeException | SQLException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException("Not deleted");
		}
		
		
		return false;
	}
	

}
