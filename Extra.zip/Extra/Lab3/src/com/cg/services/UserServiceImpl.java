package com.cg.services;

import java.util.List;

import com.cg.dao.IUsersDao;
import com.cg.dao.UsersDaoImpl;
import com.cg.dto.Users;
import com.cg.exception.UsersException;

public class UserServiceImpl implements IUserService{

	IUsersDao dao = new UsersDaoImpl();
	
	@Override
	public int addUsers(Users users) throws UsersException {
		// TODO Auto-generated method stub
		return dao.addUsers(users);
	}

	@Override
	public List<Users> showAll() throws UsersException {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

}
