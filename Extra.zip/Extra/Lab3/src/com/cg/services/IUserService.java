package com.cg.services;

import java.util.List;

import com.cg.dto.Users;
import com.cg.exception.UsersException;

public interface IUserService {

	public int addUsers(Users users) throws UsersException;
	public List<Users> showAll() throws UsersException;
}
