package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Users;
import com.cg.exception.UsersException;
import com.cg.services.IUserService;
import com.cg.services.UserServiceImpl;


@WebServlet("*.do")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IUserService service;
  
    public RegisterController() {
    	service = new UserServiceImpl();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
		}
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	
	private void processRequest(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		String path=request.getServletPath();
		System.out.println(path);
		
		if(path.equals("/registerController.do")){
		RequestDispatcher rs = request.getRequestDispatcher("addUser.jsp");
		rs.forward(request, response);
		}
		if(path.equals("/userAdd.do")){
			
			List<Users> myList = new ArrayList<Users>();
			
			String firstname = request.getParameter("fname");
			String lastname= request.getParameter("lname");
			String password = request.getParameter("jsal");
			char gender = request.getParameter("gender").charAt(0);
			
			String arr[]=request.getParameterValues("skill");
			String skillSet=null;
			for(int i=0;i<arr.length;i++){
				if(!arr[i].equals(null)){
					skillSet=arr[i];
					System.out.println();
					
				}
				
			}
			for(int j=0;j<arr.length;j++){
				if(!arr[j].equals(null) && !arr[j].contains(skillSet) ){
					skillSet=skillSet+","+arr[j];
				}
			}
			
			
			/*String skill1= request.getParameter("skill");
			String skill2= request.getParameter("skill");
			String skill3= request.getParameter("skill");
			String skill4= request.getParameter("skill");*/
			//
			
			//String skillFinal= ((skill1.concat(skill2)).concat(skill3)).concat(skill4);
		
			String city = request.getParameter("city");
		
			
			Users users = new Users(firstname,lastname,password,gender,skillSet,city);

		
			
			try {
				int i =service.addUsers(users);
				if(i==1){
					myList = service.showAll();
					request.setAttribute("data", myList);
					RequestDispatcher rd = request.getRequestDispatcher("showAll.jsp");
					rd.forward(request, response);
				}
				System.out.println("in controller------>inserted");
				
			} catch (UsersException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
	}

}
